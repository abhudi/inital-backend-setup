const jwt = require('jsonwebtoken');
const { ERROR_CODES, MESSAGES } = require('../config/constant');
const { getModel } = require('../modelManager');
const { flatMap, get, intersection, map, uniq } = require('lodash');
const { verifyToken } = require('../modules/auth/services/auth.service');
const config = require('../config/config');
const { getDomain } = require('../utils/util');
const { Op } = require('sequelize');

module.exports.authenticateToken = async (req, res, next) => {
    const token = req.headers['authorization'];

    if (!token) {
        return res.status(401).json({
            code: ERROR_CODES.AUTH_FAILED
        });
    }

    const bearerToken = token.split(" ")[1];

    const { valid, decoded, error } = verifyToken(bearerToken);

    if (!valid) {
        return res.status(401).json({
            code: ERROR_CODES.AUTH_FAILED
        });
    }

    if (!decoded.userId && decoded.subdomain) {
        return res.status(401).json({
            code: ERROR_CODES.AUTH_FAILED
        });
    }

    const Users = getModel('User');
    
    let user = await Users.findOne({
        where: { id: decoded.userId, isActive: true }
    })
    
    if (!user) {
        return res.status(401).json({
            code: ERROR_CODES.AUTH_FAILED
        });
    }

    user = JSON.parse(JSON.stringify(user));

    req.user = user;
    req.displayName = user.displayName || 'User';


    if (user.email) req.email = user.email
    if (decoded.userId) req.userId = decoded.userId
 
    // if super admin
    if (decoded.isSuperAdmin) {
        
        req.isSuperAdmin = decoded.isSuperAdmin;
        next();
        return;
    }
};


module.exports.superAdminAutCheck = (req, res, next) => {
    const token = req.headers['authorization'];

    if (!token) {
        return res.status(401).json({
            code: ERROR_CODES.AUTH_FAILED
        });
    }

    const bearerToken = token.split(" ")[1];

    const { valid, decoded, error } = verifyToken(bearerToken);

    if (!valid) {
        return res.status(401).json({
            code: ERROR_CODES.AUTH_FAILED
        });
    }

    if (!decoded || !decoded.isSuperAdmin) {
        return res.status(401).json({
            code: ERROR_CODES.AUTH_FAILED
        });
    }

    if (decoded.userId) req.userId = decoded.userId
    if (decoded.subdomain) req.subdomain = decoded.subdomain;

    next()
};


