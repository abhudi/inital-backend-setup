const multer = require('multer');
const storage = multer.memoryStorage();

// Multer configuration with size limit and custom file filter
const upload = multer({
  storage: storage,
  limits: { fileSize: 1024 * 1024 * 50 }, // 50MB file size limit
 // fileFilter: fileFilter, // Custom file filter for extension and content type
});

module.exports = upload;
