const path = require('path');
const fileType = require('file-type');
const sanitizeFilename = require('sanitize-filename');

// Allowed file extensions for image files (without .xls)
const allowedExtensions = ['.jpeg', '.jpg', '.png', '.gif', '.bmp', '.xls', '.xlsx'];

// Function to manually check if a buffer is an .xls file
const isXlsFile = (buffer) => {
  // .xls files start with the magic numbers 'D0 CF 11 E0'
  return buffer && buffer.length > 4 &&
         buffer[0] === 0xD0 &&
         buffer[1] === 0xCF &&
         buffer[2] === 0x11 &&
         buffer[3] === 0xE0;
};

// Middleware to validate uploaded files
const validateFiles = async (req, res, next) => {
  try {
    let filesToValidate = [];
    
    // If it's a single file upload, push it into the array
    if (req.file) {
      filesToValidate = [req.file];
    }
    // If it's multiple files uploaded with different field names
    if (req.files) {
      // Flatten the files array
      Object.values(req.files).forEach(files => {
        filesToValidate = filesToValidate.concat(files);
      });
    }

    // If no files were uploaded, return an error

    // Iterate over each file to validate
    for (const file of filesToValidate) {
      console.log('Checking file:', file.originalname);

      // Step 1: Check file extension
      const fileExtension = path.extname(file.originalname).toLowerCase();
      console.log('File extension:', fileExtension);

      // If the extension is not allowed, reject the upload
      if (!allowedExtensions.includes(fileExtension) && !isXlsFile(file.buffer)) {
        console.log('File extension not allowed:', fileExtension);
        return res.status(400).json({ 
          error: `Invalid file type for ${file.originalname}.` 
        });
      }

      // Step 2: Check file content using file-type (actual file signature)
      const type = await fileType.fromBuffer(file.buffer);
      console.log('Detected file type using file-type:', type);

      // If not a recognized file type and not an .xls, reject the upload
      if (!isXlsFile(file.buffer) && (!type || !allowedExtensions.includes(`.${type.ext}`))) {
        return res.status(400).json({ 
          error: `Invalid file content type for ${file.originalname}. Detected content type does not match allowed extensions.` 
        });
      }

      // Step 3: Sanitize the file name
      file.originalname = sanitizeFilename(file.originalname);
    }

    // If all files are valid, proceed to the next middleware/controller
    next();
  } catch (error) {
    console.error('Error validating files:', error);
    res.status(500).json({ error: 'Failed to validate files.' });
  }
};

module.exports = validateFiles;
