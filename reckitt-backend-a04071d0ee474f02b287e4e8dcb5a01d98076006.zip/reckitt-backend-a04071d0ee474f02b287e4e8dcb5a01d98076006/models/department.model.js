const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const Department = sequelize.define('Department', {
        departmentId: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            allowNull: false,
        },
        orderBy: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0,
        },
        name: {
            type: DataTypes.STRING(55),
            allowNull: true,
        },
    }, {
        tableName: 'department',
        freezeTableName: true,
        timestamps: false,
    });

    return Department;
};
