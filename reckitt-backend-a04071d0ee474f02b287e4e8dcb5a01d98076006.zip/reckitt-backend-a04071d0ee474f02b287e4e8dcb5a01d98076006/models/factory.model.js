const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const Factory = sequelize.define('Factory', {
        factoryId: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        factoryName: {
            type: DataTypes.STRING(100),
            allowNull: true,
            unique: true, // Add unique constraint
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: DataTypes.NOW,
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: DataTypes.NOW,
        },
    }, {
        tableName: 'factories',
        freezeTableName: true,
        timestamps: false,
        indexes: [
            {
                unique: true, // Ensure the index is unique
                fields: ['factoryName'], // Index on factoryName field
            },
        ],
    });
    return Factory;
};
