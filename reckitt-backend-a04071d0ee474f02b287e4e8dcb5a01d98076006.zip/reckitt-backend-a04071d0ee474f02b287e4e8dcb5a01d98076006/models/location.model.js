const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const Location = sequelize.define('Locations', {
        locationId: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
            allowNull: false
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true // Making 'name' unique
        },
        location: {
            type: DataTypes.STRING,
            allowNull: true,
            unique: true // Making 'location' unique
        },
        isActive: {
            type: DataTypes.BOOLEAN,
            defaultValue: true,
        },
    }, {
        tableName: 'locations',
        modelName: 'Locations',
        freezeTableName: true,
        indexes: [
            {
                unique: true,
                fields: ['name'] // Enforcing unique constraint on 'name' field
            },
            {
                unique: true,
                fields: ['location'] // Enforcing unique constraint on 'location' field
            }
        ]
    });

    Location.associations = [
        {
            type: 'hasMany',
            target: 'Sublocations',
            foreignKey: 'locationId',
            sourceKey: 'locationId',
            as: 'subLocations',
            constraints: true
        }
    ];;

    return Location;
};
