const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const Rule = sequelize.define('Rule', {
        ruleId: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        departmentId: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        orderBy: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0,
        },
        section: {
            type: DataTypes.STRING(55),
            allowNull: true,
        },
        categoryId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0,
        },
        subCategoryId: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        ratedCriteria: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        criteriaEvaluation: {
            type: DataTypes.STRING(255),
            allowNull: true,
        },
        score: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                isIn: [['0', '1', '2', '2.5', '3', '4', '5', '6', '7', '7.5', '8', '9', '10', 'NA']],
            },
            defaultValue: '0',
        },        
        ratiosRawpack: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0,
        },
        ratiosCopack: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0,
        },
        isActive: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0,
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: DataTypes.NOW,
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: DataTypes.NOW,
            onUpdate: DataTypes.NOW,
        },
    }, {
        tableName: 'rules', // Maps to `rules` table
        freezeTableName: true, // Prevent Sequelize from pluralizing table name
        timestamps: false, // Disable automatic timestamp fields
        indexes: [
            // Create indexes for frequently queried fields
            {
                fields: ['departmentId'],
                name: 'idx_department_id',
            },
            {
                fields: ['categoryId'],
                name: 'idx_category_id',
            },
            {
                fields: ['subCategoryId'],
                name: 'idx_sub_category_id',
            },
            {
                fields: ['isActive'],
                name: 'idx_is_active',
            },
            // Composite index (optional) example
            {
                fields: ['categoryId', 'subCategoryId'],
                name: 'idx_category_sub_category',
            },
        ],
    });

    Rule.associations = [
        {
            type: 'hasOne',
            target: 'SubCategory',
            foreignKey: 'subCategoryId',
            sourceKey: 'subCategoryId',
            as: 'subCategories', 
        },
        {
            type: 'hasOne',
            target: 'Category',
            foreignKey: 'categoryId',
            sourceKey: 'categoryId',
            as: 'categories', 
        },
        {
            type: 'hasOne',
            target: 'Department',
            foreignKey: 'departmentId',
            sourceKey: 'departmentId',
            as: 'department', 
        },

    ];

    return Rule;
};
