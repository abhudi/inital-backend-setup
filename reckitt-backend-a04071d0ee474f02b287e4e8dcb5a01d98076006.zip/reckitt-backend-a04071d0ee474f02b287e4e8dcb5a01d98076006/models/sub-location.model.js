// Sublocation Model
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const Sublocation = sequelize.define('Sublocations', {
        sublocationId: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
            allowNull: false
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        locationId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            onDelete: 'CASCADE' // If a Location is deleted, delete its related Sublocations
        }
    }, {
        tableName: 'sublocations',
        modelName: 'Sublocations',
        freezeTableName: true
    });

    Sublocation.associations = [
        {
            type: 'belongsTo',
            target: 'Locations',
            foreignKey: 'locationId',
            sourceKey: 'locationId',
            as: 'location',
            constraints: true
        }
    ];

    return Sublocation;
};
