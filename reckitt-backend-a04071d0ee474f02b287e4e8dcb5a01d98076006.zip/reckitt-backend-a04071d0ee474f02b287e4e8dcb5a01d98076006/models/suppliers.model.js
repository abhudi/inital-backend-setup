const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    const Supplier = sequelize.define('Supplier',
        {
            supId: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
                allowNull: false,
            },
            factory: {
                type: DataTypes.STRING(20),
                allowNull: true,
            },
            supplierName: {
                type: DataTypes.STRING(40),
                allowNull: false,
            },
            supplierNumber: {
                type: DataTypes.STRING(30),
                allowNull: true,
            },
            supplierManufacturerName: {
                type: DataTypes.STRING(40),
                allowNull: false,
            },
            siteAddress: {
                type: DataTypes.TEXT,
                allowNull: false,
            },
            factoryId: {
                type: DataTypes.INTEGER,
                allowNull: false,
            },
            procurementCategoryId: {
                type: DataTypes.INTEGER,
                allowNull: false,
            },
            supplierCategoryId: {
                type: DataTypes.INTEGER,
                allowNull: false,
            },
            locationId: {
                type: DataTypes.INTEGER,
                allowNull: true,
                defaultValue: 0,
            },
            sublocationId: {
                type: DataTypes.INTEGER,
                allowNull: true,
                defaultValue: 0,
            },
            cleanDataStatus: {
                type: DataTypes.INTEGER,
                allowNull: false,
                defaultValue: 0,
            },
            dataFile: {
                type: DataTypes.STRING(100),
                allowNull: true,
            },
            gmpFile: {
                type: DataTypes.STRING(255),
                allowNull: true,
            },
            gdpFile: {
                type: DataTypes.STRING(255),
                allowNull: true,
            },
            reachFile: {
                type: DataTypes.STRING(255),
                allowNull: true
            },
            isoFile: {
                type: DataTypes.STRING(255),
                allowNull: true,
            },
            createdAt: {
                type: DataTypes.DATE,
                allowNull: false,
                defaultValue: DataTypes.NOW,
            },
        },
        {
            tableName: 'suppliers', // Maps to `supplier` table
            freezeTableName: true, // Prevent Sequelize from pluralizing table name
            timestamps: false, // Disable automatic timestamp fields
        }
    );

    // Define associations outside the model
    Supplier.associations = [
        {
            type: 'belongsTo',
            target: 'Category',
            targetKey: 'categoryId',
            foreignKey: 'supplierCategoryId',
            as: 'category', // Alias for the relationship
        },
        {
            type: 'belongsTo',
            target: 'Factory',
            targetKey: 'factoryId',
            foreignKey: 'factoryId',
            as: 'factoryName', // Alias for the relationship
        },
        {
            type: 'belongsTo',
            target: 'SubCategory',
            targetKey: 'subCategoryId',
            foreignKey: 'procurementCategoryId',
            as: 'subCategories', // Alias for the relationship
        },
        {
            type: 'belongsTo',
            target: 'Locations',
            targetKey: 'locationId',
            foreignKey: 'locationId',
            as: 'location', // Alias for the relationship
        },
        {
            type: 'belongsTo',
            target: 'Sublocations',
            targetKey: 'sublocationId',
            foreignKey: 'sublocationId',
            as: 'sublocations', // Alias for the relationship
        },
    ];

    return Supplier;
};
