const { handleCatchError } = require('../../../utils/error.service');
const { ERROR_CODES } = require('../../../config/constant');
const { isInteger } = require('lodash');
const { getModel } = require('../../../modelManager');
const { where, Op } = require('sequelize');
const { parseQueryStringToObject } = require('../../../utils/util');

exports.createCompany = async (req, res) => {
    try {
        console.log("post api requested");
        
    } catch (error) {
        return handleCatchError(error, req, res)
    }
}