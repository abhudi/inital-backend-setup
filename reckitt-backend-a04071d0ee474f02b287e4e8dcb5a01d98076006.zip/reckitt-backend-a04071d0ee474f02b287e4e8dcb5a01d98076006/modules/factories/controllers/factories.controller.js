const { where } = require("sequelize");
const { ERROR_CODES } = require("../../../config/constant");
const { getModel, include } = require("../../../modelManager");
const { handleCatchError } = require("../../../utils/error.service");
const { includes } = require("lodash");
const Factory = getModel('Factory');

exports.addFactory = async (req,res)=>{
    try {
        const { factoryName } = req.body;
        if (!factoryName) {
            return res.status(405).json({
             code: ERROR_CODES.INVALID_PARAMS,
             error: "Please provide factoryname"
            })
         }

        const factory = await Factory.create({factoryName});
        return res.status(200).json({
            code: ERROR_CODES.SUCCESS,
            data: factory
        })
        
    } catch (error) {
        return handleCatchError(error, req, res)
    }
}

exports.updateFactory = async (req,res)=>{
    try {
        const { factoryName } = req.body;
        const { factoryId } = req.params;
         
        if (!factoryName) {
           return res.status(405).json({
            code: ERROR_CODES.INVALID_PARAMS,
            error: "Please provide factoryname"
           })
        }

        const findFactory  = await Factory.findOne({ where: { factoryId }})

        if (!findFactory) {
            return res.status(404).json({
                code: ERROR_CODES.NOT_FOUND,
                error: "Factory not found"
               }) 
        }

        const factory = await Factory.update({ factoryName }, { where: { factoryId }});
        return res.status(200).json({
            code: ERROR_CODES.SUCCESS,
            data: factory
        })
        
    } catch (error) {
        return handleCatchError(error, req, res)
    }
}

exports.getFactory = async (req,res)=>{
    try {
        const factory = await Factory.findAll();
        return res.status(200).json({
            code: ERROR_CODES.SUCCESS,
            data: factory
        })
        
    } catch (error) {
        return handleCatchError(error, req, res)
    }
}

exports.deleteFactory = async (req,res)=>{
    try {
        const { factoryId } = req.params;
        const findFactory  = await Factory.findOne({ where: {factoryId}})

        if (!findFactory) {
            return res.status(404).json({
                code: ERROR_CODES.NOT_FOUND,
                error: "Factory not found"
               }) 
        }

        const factory = await Factory.destroy({ where: {factoryId}});
        return res.status(200).json({
            code: ERROR_CODES.SUCCESS,
            data: factory
        })
        
    } catch (error) {
        return handleCatchError(error, req, res)
    }
}