const express = require('express');
const router = express.Router();

router.use('/', require('./routes/factories.route'));

module.exports = router;