const express = require('express');
const { addFactory, getFactory, updateFactory, deleteFactory } = require('../controllers/factories.controller');
const router = express.Router();

router.post("/factory", addFactory)
router.get("/factory", getFactory)
router.put("/factory/:factoryId", updateFactory)
router.delete("/factory/:factoryId", deleteFactory)
module.exports = router