const { ERROR_CODES } = require("../../../config/constant");
const { getModel, include } = require("../../../modelManager");
const { handleCatchError } = require("../../../utils/error.service");
const { includes } = require("lodash");
const Factory = getModel('Factory');
const { Op, where } = require('sequelize');
const { parseQueryStringToObject } = require("../../../utils/util");
const { search } = require("../routes/location.route");
const Locations = getModel('Locations');
const Sublocations = getModel('Sublocations');
exports.addLocation = async (req, res) => {
    try {
        const data = req.body;
        if (!data.name) {
            return res.status(405).json({
                code: ERROR_CODES.INVALID_PARAMS,
                error: "Please provide location name"
            });
        }

        if (!data.location) {
            return res.status(405).json({
                code: ERROR_CODES.INVALID_PARAMS,
                error: "Please provide location field"
            });
        }


        const [existingLocationByName, existingLocationByLocation] = await Promise.all([
            Locations.findOne({
                where: {
                    name: {
                        [Op.iLike]: data.name  
                    }
                }
            }),
            Locations.findOne({
                where: {
                    location: {
                        [Op.iLike]: data.location  
                    }
                }
            })
        ]);

        if (existingLocationByName) {
            return res.status(400).json({
                code: ERROR_CODES.DUPLICATE_ENTRY,
                error: "A location with the same name already exists"
            });
        }

        if (existingLocationByLocation) {
            return res.status(400).json({
                code: ERROR_CODES.DUPLICATE_ENTRY,
                error: "A location with the same location field already exists"
            });
        }
        const doc = {
            name: data.name,
            location: data.location
        }
        const newLocation = await Locations.create(doc);

        return res.status(201).json({
            code: ERROR_CODES.SUCCESS,
            data: newLocation
        });

    } catch (error) {
        return handleCatchError(error, req, res);
    }
};

exports.updateLocation = async (req, res) => {
    try {
        const { locationId } = req.params; 
        const data = req.body;

        if (!data.name) {
            return res.status(405).json({
                code: ERROR_CODES.INVALID_PARAMS,
                error: "Please provide location name"
            });
        }

        if (!data.location) {
            return res.status(405).json({
                code: ERROR_CODES.INVALID_PARAMS,
                error: "Please provide location field"
            });
        }

        const location = await Locations.findByPk(locationId);
        if (!location) {
            return res.status(404).json({
                code: ERROR_CODES.NOT_FOUND,
                error: "Location not found"
            });
        }

        // Check for duplicates (excluding the current record being updated)
        const [existingLocationByName, existingLocationByLocation] = await Promise.all([
            Locations.findOne({
                where: {
                    name: {
                        [Op.iLike]: data.name
                    },
                    locationId: {
                        [Op.ne]: locationId // Exclude the current location being updated
                    }
                }
            }),
            Locations.findOne({
                where: {
                    location: {
                        [Op.iLike]: data.location
                    },
                    locationId: {
                        [Op.ne]: locationId // Exclude the current location being updated
                    }
                }
            })
        ]);

        if (existingLocationByName) {
            return res.status(400).json({
                code: ERROR_CODES.DUPLICATE_ENTRY,
                error: "A location with the same name already exists"
            });
        }

        // If a location with the same location field already exists
        if (existingLocationByLocation) {
            return res.status(400).json({
                code: ERROR_CODES.DUPLICATE_ENTRY,
                error: "A location with the same location field already exists"
            });
        }

        const updatedLocation = await Locations.update({
            name: data.name,
            location: data.location
        }, {where: { locationId: locationId }});

        return res.status(200).json({
            code: ERROR_CODES.SUCCESS,
            data: updatedLocation
        });

    } catch (error) {
        return handleCatchError(error, req, res);
    }
};

exports.deleteLocation = async (req, res) => {
    try {
        const { locationId } = req.params;

        const location = await Locations.findByPk(locationId);
        if (!location) {
            return res.status(404).json({
                code: ERROR_CODES.NOT_FOUND,
                error: "Location not found"
            });
        }

        await location.destroy({ where: { locationId: locationId }});

        return res.status(200).json({
            code: ERROR_CODES.SUCCESS,
            message: "Location deleted successfully"
        });
    } catch (error) {
        return handleCatchError(error, req, res);
    }
};

exports.getLocations = async (req, res) => {
    try {
        const { companyId } = req.params;
        const {
            limit = 100,
            page = 1,
            search = null,
            filters = {},
            sortBy = '',
            sortOrder = '',
            include = [],
        } = parseQueryStringToObject(req.query);

        const limitNumber = parseInt(limit, 10) || 100;
        const pageNumber = parseInt(page, 10) || 1;
        const offset = (pageNumber - 1) * limitNumber;
        const { count, result } = await this.getLocationsList({
            companyId,
            offset: offset,
            limit: limitNumber,
            search: search,
            filters: typeof filters == 'object' ? filters : {},
            include: typeof include == 'string' ? include.split(',') : [],
            sortBy,
            sortOrder
        });
  
        return res.status(200).json({
            code: ERROR_CODES.SUCCESS,
            page: pageNumber,
            limit: limitNumber,
            total: count,
            data: result,
            totalPages: Math.ceil(count / limitNumber),
            filters: filters,
            search: search
        });
    } catch (error) {
        return handleCatchError(error, req, res);
    }
  };
  
exports.getLocationsList = async (params) => {
    const {
        offset,
        limit,
        filters = {},
        sortBy,
        sortOrder,
        search
    } = params;
  
    const countQuery = {
        where: { },
        include: []
    };
  
    const whereQuery = {
        where: { },
        offset: offset,
        limit: limit,
        include: [
          {
            model: Sublocations,
            as: 'subLocations'
          }
      ]
    };

    if (search) {
        whereQuery.where['name'] = { [Op.like]: `%${search}%` };
        countQuery.where['name'] = { [Op.like]: `%${search}%` };
        
    }

    const count = await Locations.count(countQuery);
    const result = await Locations.findAll(whereQuery);
    return { result, count };
  };
