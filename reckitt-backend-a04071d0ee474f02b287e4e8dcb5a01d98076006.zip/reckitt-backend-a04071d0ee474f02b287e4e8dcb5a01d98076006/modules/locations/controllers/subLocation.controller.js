const { ERROR_CODES } = require("../../../config/constant");
const { getModel, include } = require("../../../modelManager");
const { handleCatchError } = require("../../../utils/error.service");
const { includes } = require("lodash");
const Factory = getModel('Factory');
const { Op, where } = require('sequelize');
const { parseQueryStringToObject } = require("../../../utils/util");
const { search, param } = require("../routes/location.route");
const Locations = getModel('Locations');
const Sublocations = getModel('Sublocations');

exports.addSublocation = async (req, res) => {
    try {
        const { locationId, name } = req.body;

        if (!locationId) {
            return res.status(405).json({
                code: ERROR_CODES.INVALID_PARAMS,
                error: "Please provide locationId",
            });
        }
        if (!name) {
            return res.status(405).json({
                code: ERROR_CODES.INVALID_PARAMS,
                error: "Please provide sublocation name",
            });
        }

        const parentLocation = await Locations.findByPk(locationId);
        if (!parentLocation) {
            return res.status(404).json({
                code: ERROR_CODES.NOT_FOUND,
                error: "Parent location not found",
            });
        }

        const existingSublocation = await Sublocations.findOne({
            where: {
                name: { [Op.iLike]: name }, 
                locationId,
            },
        });
        if (existingSublocation) {
            return res.status(400).json({
                code: ERROR_CODES.DUPLICATE_ENTRY,
                error: "A sublocation with the same name already exists for this location",
            });
        }

        const sublocation = await Sublocations.create({
            locationId,
            name,
        });

        return res.status(201).json({
            code: ERROR_CODES.SUCCESS,
            data: sublocation,
        });
    } catch (error) {
        return handleCatchError(error, req, res);
    }
};

exports.getSubLocations = async (req, res) => {
    try {
        const { companyId } = req.params;
        const {
            limit = 100,
            page = 1,
            search = null,
            filters = {},
            sortBy = '',
            sortOrder = '',
            include = [],
        } = parseQueryStringToObject(req.query);

        const limitNumber = parseInt(limit, 10) || 100;
        const pageNumber = parseInt(page, 10) || 1;
        const offset = (pageNumber - 1) * limitNumber;
        const { count, result } = await this.getSubLocationsList({
            companyId,
            offset: offset,
            limit: limitNumber,
            search: search,
            filters: typeof filters == 'object' ? filters : {},
            include: typeof include == 'string' ? include.split(',') : [],
            sortBy,
            sortOrder
        });
  
        return res.status(200).json({
            code: ERROR_CODES.SUCCESS,
            page: pageNumber,
            limit: limitNumber,
            total: count,
            data: result,
            totalPages: Math.ceil(count / limitNumber),
            filters: filters,
            search: search
        });
    } catch (error) {
        return handleCatchError(error, req, res);
    }
  };
  
exports.getSubLocationsList = async (params) => {
    const {
        offset,
        limit,
        filters = {},
        sortBy,
        sortOrder,
        search
    } = params;
  
    const countQuery = {
        where: { },
        include: []
    };
  
    const whereQuery = {
        where: { },
        offset: offset,
        limit: limit,
        include: [
          {
            model: Locations,
            as: 'location'
          }
      ]
    };

    if (search) {
        whereQuery.where['name'] = { [Op.like]: `%${search}%` };
        countQuery.where['name'] = { [Op.like]: `%${search}%` };
        
    }

    if ( filters.locationId ) {
        whereQuery.where['locationId'] = filters.locationId
        countQuery.where['locationId'] = filters.locationId
    }

    if ( filters.sublocationId ) {
        whereQuery.where['sublocationId'] = filters.sublocationId
        countQuery.where['sublocationId'] = filters.sublocationId
    }

    const count = await Sublocations.count(countQuery);
    const result = await Sublocations.findAll(whereQuery);
    return { result, count };
  };

exports.getSubLocationsById = async (req, res) =>{
   try {
    const { locationId } = req.params;
     
    const subLocationBasedLocation = await Sublocations.findAll({ where: { locationId: locationId }});

    return res.status(200).json({
        code: ERROR_CODES.SUCCESS,
        data: subLocationBasedLocation
    })

   } catch (error) {
    return handleCatchError(error, req, res)
   }
}  

exports.updateSublocation = async (req, res) => {
    try {
        const { sublocationId } = req.params;
        const { locationId, name } = req.body
        // Validate required fields
        if (!sublocationId) {
            return res.status(405).json({
                code: ERROR_CODES.INVALID_PARAMS,
                error: "Please provide sublocationId",
            });
        }

        if (!locationId) {
            return res.status(405).json({
                code: ERROR_CODES.INVALID_PARAMS,
                error: "Please provide locationId",
            });
        }

        if (!name) {
            return res.status(405).json({
                code: ERROR_CODES.INVALID_PARAMS,
                error: "Please provide sublocation name",
            });
        }

        // Check if the sublocation exists
        const sublocation = await Sublocations.findByPk(sublocationId);
        if (!sublocation) {
            return res.status(404).json({
                code: ERROR_CODES.NOT_FOUND,
                error: "Sublocation not found",
            });
        }

        // Check if the parent location exists
        const parentLocation = await Locations.findByPk(locationId);
        if (!parentLocation) {
            return res.status(404).json({
                code: ERROR_CODES.NOT_FOUND,
                error: "Parent location not found",
            });
        }

        // Check for duplicate name within the same location
        const duplicateSublocation = await Sublocations.findOne({
            where: {
                name: { [Op.iLike]: name },
                locationId,
                sublocationId: { [Op.ne]: sublocationId }, // Ensure it's not the current sublocation
            },
        });

        if (duplicateSublocation) {
            return res.status(400).json({
                code: ERROR_CODES.DUPLICATE_ENTRY,
                error: "A sublocation with the same name already exists for this location",
            });
        }

        // Update the sublocation
        sublocation.locationId = locationId;
        sublocation.name = name;
        await sublocation.save();

        return res.status(200).json({
            code: ERROR_CODES.SUCCESS,
            data: sublocation,
        });
    } catch (error) {
        return handleCatchError(error, req, res);
    }
};