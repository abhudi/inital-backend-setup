const express = require('express');
const { addLocation, updateLocation, deleteLocation, getLocations } = require('../controllers/location.controller');
const { addSublocation, getSubLocations, getSubLocationsById } = require('../controllers/subLocation.controller');
const router = express.Router();

router.post("/location", addLocation);
router.get("/location", getLocations);
router.put("/location/:locationId", updateLocation);
router.delete("/location/:locationId", deleteLocation);

// Sub locations
router.post("/sub-location", addSublocation);
router.get("/sub-location", getSubLocations);
router.get("/sub-location/:locationId", getSubLocationsById);
router.put("/sub-location/:SubLocationId", updateLocation);


module.exports = router
  