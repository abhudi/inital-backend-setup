const XLSX = require('xlsx'); // Import xlsx library    
const { handleCatchError } = require('../../../utils/error.service');
const { ERROR_CODES } = require('../../../config/constant');
const { isInteger, map, uniq, groupBy, includes } = require('lodash');
const { getModel } = require('../../../modelManager');
const { where, Op } = require('sequelize');
const { parseQueryStringToObject } = require('../../../utils/util');
const Category = getModel('Category');
const SubCategory = getModel('SubCategory');
const Factory = getModel('Factory');
const Supplier = getModel('Supplier');
const Department = getModel('Department');
const Rule = getModel('Rule');
const xlsx = require('xlsx');

exports.addRule = async (req,res)=>{

try {
    const data = req.body;
  
    if (!data.orderBy || !isInteger(+data.orderBy) || +data.orderBy === 0) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide orderBy",
        key: "orderBy"
      });
    }

    if (!data.categoryId || !isInteger(+data.categoryId) || +data.categoryId === 0) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide Category",
        key: "categoryId"
      });
    }

    if (!data.suppCategoryId || !isInteger(+data.suppCategoryId) || +data.suppCategoryId === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide suppCategoryId",
          key: "suppCategoryId"
        });
      }

      if (!data.ratiosRawpack || !isInteger(+data.ratiosRawpack) || +data.ratiosRawpack === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide RatiosRawpack",
          key: "ratiosRawpack"
        });
      }  

      if (!data.ratiosCopack || !isInteger(+data.ratiosCopack) || +data.ratiosCopack === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide RatiosCopack",
          key: "ratiosCopack"
        });
      }
      const VALID_SCORES = ['0', '1', '2', '2.5', '3', '4', '5', '6', '7', '7.5', '8', '9', '10', 'NA'];

// Assuming `data` contains the incoming request body
if (!data.score || !VALID_SCORES.includes(data.score)) {
    return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide a valid score. Valid values are: '0', '1', '2', '2.5', '3', '4', '5', '6', '7', '7.5', '8', '9', '10', 'NA'.",
        key: "score"
    });
}

if (!data.departmentId || !isInteger(+data.departmentId) || +data.departmentId === 0) {
  return res.status(400).json({
    code: ERROR_CODES.INVALID_PARAMS,
    error: "Please provide departmentId",
    key: "departmentId"
  });
}
  
    const [findsupplierCategory, findprocurementCategory, findDepartment] = await Promise.all([
     Category.findOne({ where: { categoryId: data.categoryId }}),
     SubCategory.findOne({ where: { subCategoryId: data.suppCategoryId }}), 
     Department.findOne({ where: { departmentId: data.departmentId }}), 

    ])
    
    if (!findsupplierCategory) {
      return res.status(404).json({
        code: ERROR_CODES.NOT_FOUND,
        error: "Category not found"
      })
    }

    if (!findprocurementCategory) {
      return res.status(404).json({
        code: ERROR_CODES.NOT_FOUND,
        error: "Sub Category not found"
      })
    }

    if (!findDepartment) {
      return res.status(404).json({
        code: ERROR_CODES.NOT_FOUND,
        error: " Department not found"
      })
    }
    const doc = {
      "departmentId": data.departmentId,
      "orderBy": data.orderBy,
      "section": data.section || null,
      "categoryId": data.categoryId,
      "suppCategoryId": data.suppCategoryId,
      "ratedCriteria": data.ratedCriteria || null,
      "criteriaEvaluation": data.criteriaEvaluation || null,
      "score": data.score || '0',
      "ratiosRawpack": data.ratiosRawpack || 0,
      "ratiosCopack": data.ratiosCopack || 0,
  }
  
  const createRule =  await Rule.create(doc);
  return res.status(200).json({
    code: ERROR_CODES.SUCCESS,
    data: createRule
  })
   
} catch (error) {
    return handleCatchError(error, req, res)
};
    
}

exports.updateSupplier = async (req,res)=>{

  try {
      const data = req.body;
      const { supId } = req.params;
      const gmpFile = req.files?.gmpFile?.[0] || null;
      const gdpFile = req.files?.gdpFile?.[0] || null;
      const reachFile = req.files?.reachFile?.[0] || null;
      const isoFile = req.files?.isoFile?.[0] || null;
      
      if (!data.supplierName) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide supplier name",
          key: "supplierName"
        });
      }
  
      if (!data.supplierManufacturerName) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide supplier manufacturer name",
          key: "supplierManufacturerName"
        });
      }
  
      if (!data.siteAddress) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide site address",
          key: "siteAddress"
        });
      }
      if (!data.factoryId || !isInteger(+data.factoryId) || +data.factoryId === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide a valid factoryId",
          key: "factoryId"
        });
      }
      
      if (!data.procurementCategoryId || !isInteger(+data.procurementCategoryId) || +data.procurementCategoryId === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide a valid procurementCategory",
          key: "procurementCategory"
        });
      }
      
      if (!data.supplierCategoryId || !isInteger(+data.supplierCategoryId) || +data.supplierCategoryId === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide a valid supplierCategory",
          key: "supplierCategory"
        });
      }
      
  
      if (!data.warehouseLocation) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide warehouseLocation",
          key: "warehouseLocation"
        });
      }
  
      if (data.gmpFile) {
  
      }
  
      const [findsupplierCategory, findprocurementCategory, findFactory, findSupplier] = await Promise.all([
       Category.findOne({ where: { categoryId: data.supplierCategoryId }}),
       SubCategory.findOne({ where: { subCategoryId: data.procurementCategoryId }}),
       Factory.findOne({ where: { factoryId: data.factoryId }}),
       Supplier.findOne({ where: { supId }})
  
      ])

      if (!findSupplier) {
        return res.status(404).json({
          code: ERROR_CODES.NOT_FOUND,
          error: "Suplier  not found"
        })
      }

      if (!findsupplierCategory) {
        return res.status(404).json({
          code: ERROR_CODES.NOT_FOUND,
          error: "Suplier Category not found"
        })
      }
  
      if (!findprocurementCategory) {
        return res.status(404).json({
          code: ERROR_CODES.NOT_FOUND,
          error: "Procurement Category not found"
        })
      }
  
      if (!findFactory) {
        return res.status(404).json({
          code: ERROR_CODES.NOT_FOUND,
          error: "Factory not found"
        })
      }
  
     const doc = {
      "supplierName": data.supplierName,
      "supplierNumber": data.supplierNumber,
      "supplierManufacturerName": data.supplierManufacturerName,
      "siteAddress": data.siteAddress,
      "factoryId" : data.factoryId,
      "procurementCategoryId": data.procurementCategoryId,
      "supplierCategoryId": data.supplierCategoryId,
      "warehouseLocation": data.warehouseLocation,
      "region": data.region || null,
      "factory": data.factory || null
     }
    const updateSupplier =  await Supplier.update(doc, { where: { supId }});
    return res.status(200).json({
      code: ERROR_CODES.SUCCESS,
      data: updateSupplier
    })
     
  } catch (error) {
      return handleCatchError(error, req, res)
  };
      
  }
exports.deleteSupplier = async (req,res)=>{
  try {
    const { supId } = req.params;
    const findSupplier = await  Supplier.findOne({ where: { supId }});
    if (!findSupplier) {
      return res.status(404).json({
        code: ERROR_CODES.NOT_FOUND,
        error: "Suplier  not found"
      })
    }

    const deletSupplier =  await Supplier.destroy({ where: { supId }});
    return res.status(200).json({
      code: ERROR_CODES.SUCCESS,
      data: deletSupplier
    })
     
  } catch (error) {
    return handleCatchError(error, req, res)
  }
} 

exports.getSuppliers = async (req, res) => {
  try {
      const { companyId } = req.params;
      const {
          limit = 100,
          page = 1,
          filters = {},
          sortBy = '',
          sortOrder = '',
          include = [],
      } = parseQueryStringToObject(req.query);

      const limitNumber = parseInt(limit, 10) || 100;
      const pageNumber = parseInt(page, 10) || 1;
      const offset = (pageNumber - 1) * limitNumber;

      const { result, count } = await this.getSuppliersList({
          companyId,
          offset: offset,
          limit: limitNumber,
          filters: typeof filters === 'object' ? filters : {},
          sortBy,
          sortOrder
      });

      return res.status(200).json({
          code: ERROR_CODES.SUCCESS,
          page: pageNumber,
          limit: limitNumber,
          total: count,
          data: result,
          totalPages: Math.ceil(count / limitNumber),
          filters: filters,
      });
  } catch (error) {
      return handleCatchError(error, req, res);
  }
};

exports.getSuppliersList = async (params) => {
  const {
      companyId,
      offset,
      limit,
      filters = {},
      sortBy,
      sortOrder
  } = params;

  const countQuery = {
      where: { },
      include: []
  };

  const whereQuery = {
      where: { },
      offset: offset,
      limit: limit,
      include: [
        {
          model: Category,
          as: 'category'
        },
        {
          model: SubCategory,
          as: 'subCategories'
        },
        {
          model: Factory,
          as: 'factoryName'
        }
    ]
  };

  whereQuery.order = [
      sortBy ? [sortBy, ['asc', 'desc'].includes(sortOrder) ? sortOrder : 'desc'] : ['supId', 'desc']
  ];



  if (filters.supplierCategoryId) {
      whereQuery.where['supplierCategoryId'] = filters.supplierCategoryId;
      countQuery.where['supplierCategoryId'] = filters.supplierCategoryId;
  }
  if (filters.procurementCategoryId) {
      whereQuery.where['procurementCategoryId'] = filters.procurementCategoryId;
      countQuery.where['procurementCategoryId'] = filters.procurementCategoryId;
  }
  if (filters.factoryId) {
    whereQuery.where['factoryId'] = filters.factoryId;
    countQuery.where['factoryId'] = filters.factoryId;
}
  const count = await Supplier.count(countQuery);
  const result = await Supplier.findAll(whereQuery);
  return { result, count };
};

exports.addBulkRules = async (req, res) => {
  try {
    const file = req.file;

    if (!file) {
      return res.status(400).json({ error: 'No file uploaded.' });
    }

    // Check if the uploaded file is a valid Excel file
    const isExcelFile = (file.mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
                         file.mimetype === 'application/vnd.ms-excel') && 
                        (file.originalname.endsWith('.xls') || file.originalname.endsWith('.xlsx'));

    if (!isExcelFile) {
      return res.status(400).json({ error: 'Invalid file type. Please upload an Excel file.' });
    }

    console.log("Bulk API requested with a valid Excel file:", file.originalname);
    const workbook = xlsx.read(req.file.buffer, { type: 'buffer' });

    // Read the first sheet in the Excel file
    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];

    // Convert the worksheet data to JSON format
    const rulesData = xlsx.utils.sheet_to_json(worksheet);
    const groupedData = groupBy(rulesData, (item) =>
      `${item.orderby}|${item.section}|${item.category}|${item.subCategory}|${item.criteri}`
  );

    // IDs to check existence against
    const departmentIds = uniq(map(rulesData || [], 'departmentId'));
    const categoryIds = uniq(map(rulesData || [], 'categoryId'));
    const subCategoryIds = uniq(map(rulesData || [], 'subCategoryId'));

    // Find existing IDs in the database
    const [findDepartment, findCategory, findSubCategory] = await Promise.all([
      Department.findAll({ where: { departmentId: { [Op.in]: departmentIds } } }),
      Category.findAll({ where: { categoryId: { [Op.in]: categoryIds } } }),
      SubCategory.findAll({ where: { subCategoryId: { [Op.in]: subCategoryIds } } }),
    ]);

    const foundDepartmentIds = findDepartment.map(dep => dep.departmentId);
    const foundCategoryIds = findCategory.map(cat => cat.categoryId);
    const foundSubCategoryIds = findSubCategory.map(sub => sub.subCategoryId);
    const missingDepartments = departmentIds.filter(id => !foundDepartmentIds.includes(id));
    const missingCategories = categoryIds.filter(id => !foundCategoryIds.includes(id));
    const missingSubCategories = subCategoryIds.filter(id => !foundSubCategoryIds.includes(id));

    const validRulesData = [];
    const skippedData = [];

    rulesData.forEach(rule => {
      const hasEmptyFields = Object.values(rule).some(value => value === null || value === undefined || value === '');
      const validIds = foundDepartmentIds.includes(rule.departmentId) &&
                       foundCategoryIds.includes(rule.categoryId) &&
                       foundSubCategoryIds.includes(rule.subCategoryId);

      if (hasEmptyFields || !validIds) {
        skippedData.push({
          rule,
          reason: hasEmptyFields ? 'Empty or null fields' : 'Invalid or missing IDs',
        });
      } else {
        validRulesData.push(rule);
      }
    });

    if (validRulesData.length > 0) {
      await Rule.bulkCreate(validRulesData);
    }

    // Prepare response
    const response = {
      message: "Rules processed successfully.",
      savedCount: validRulesData.length,
      skippedData: skippedData.length > 0 ? skippedData : null,
      notFound: {
        departments: missingDepartments.length ? missingDepartments : null,
        categories: missingCategories.length ? missingCategories : null,
        subCategories: missingSubCategories.length ? missingSubCategories : null,
      }
    };

    // Adjust message if some data was skipped
    if (skippedData.length > 0 || missingDepartments.length || missingCategories.length || missingSubCategories.length) {
      response.message = "Some rules were skipped or not saved due to missing data. Please check the response for details.";
    }

    return res.status(200).json(response);

  } catch (error) {
    console.error('Error in addBulkRules:', error);
    return res.status(500).json({ error: 'Failed to process the file.' });
  }
};

exports.getRulesByCatSubCat = async (req, res) => {
  try {
    const { catId, subCatId, departmentId } = req.params;

    // Fetch all rules based on categoryId and subCategoryId
    const rules = await Rule.findAll({ 
      where: { categoryId: catId, subCategoryId: subCatId, departmentId: departmentId },
      attributes: ['section', 'ratedCriteria', 'criteriaEvaluation', 'score', 'ratiosRawpack', 'ratiosCopack']
    });

    // Structure the rules into the desired output format
    const sections = [];
    
    // Group rules by section and then by ratedCriteria
    const groupedBySection = rules.reduce((acc, rule) => {
      // Group by section
      if (!acc[rule.section]) {
        acc[rule.section] = [];
      }

      // Find or create the ratedCriteria entry within the section
      const section = acc[rule.section];
      const ratedCriteria = section.find(r => r.criteriaName === rule.ratedCriteria);
      if (ratedCriteria) {
        // If criteria already exists, add the evaluation
        ratedCriteria.evaluations.push({
          criteriaEvaluation: rule.criteriaEvaluation,
          score: rule.score,
          ratiosRawpack: rule.ratiosRawpack,
          ratiosCopack: rule.ratiosCopack
        });
      } else {
        // If criteria does not exist, create a new entry
        section.push({
          criteriaName: rule.ratedCriteria,
          evaluations: [{
            criteriaEvaluation: rule.criteriaEvaluation,
            score: rule.score,
            ratiosRawpack: rule.ratiosRawpack,
            ratiosCopack: rule.ratiosCopack
          }]
        });
      }

      return acc;
    }, {});

    // Convert the grouped data to the required structure
    Object.keys(groupedBySection).forEach(sectionName => {
      sections.push({
        sectionName,
        ratedCriteria: groupedBySection[sectionName]
      });
    });

    return res.status(200).json({
      code: ERROR_CODES.SUCCESS,
      data: { sections }
    });

  } catch (error) {
    return handleCatchError(req, res);
  }
};

exports.getAllRules = async (req, res) => {
  try {
      const {
          limit = 100,
          page = 1,
          filters = {},
          sortBy = '',
          sortOrder = '',
          include = '',
      } = parseQueryStringToObject(req.query);

      const limitNumber = parseInt(limit, 10) || 100;
      const pageNumber = parseInt(page, 10) || 1;
      const offset = (pageNumber - 1) * limitNumber;

      const { result, count } = await this.getRulesList({
          offset: offset,
          limit: limitNumber,
          filters: typeof filters === 'object' ? filters : {},
          sortBy,
          sortOrder,
          include: typeof include == 'string' ? include.split(',') : [],
      });

      return res.status(200).json({
          code: ERROR_CODES.SUCCESS,
          page: pageNumber,
          limit: limitNumber,
          total: count,
          data: result,
          totalPages: Math.ceil(count / limitNumber),
          filters: filters,
      });
  } catch (error) {
      return handleCatchError(error, req, res);
  }
};

exports.getRulesList = async (params) => {
  const {
      offset,
      limit,
      filters = {},
      sortBy,
      include = [],
      sortOrder
  } = params;

  const countQuery = {
      where: { },
      include: []
  };

  const whereQuery = {
      where: { },
      offset: offset,
      limit: limit,
      include: [
        
    ]
  };

  whereQuery.order = [
      sortBy ? [sortBy, ['asc', 'desc'].includes(sortOrder) ? sortOrder : 'desc'] : ['ruleId', 'desc']
  ];


  if (filters.departmentId) {
      whereQuery.where['departmentId'] = filters.departmentId;
      countQuery.where['departmentId'] = filters.departmentId;
  }
  if (filters.categoryId) {
      whereQuery.where['categoryId'] = filters.categoryId;
      countQuery.where['categoryId'] = filters.categoryId;
  }

  if (filters.subCategoryId) {
    whereQuery.where['subCategoryId'] = filters.subCategoryId;
    countQuery.where['subCategoryId'] = filters.subCategoryId;
  }

  if (filters.ruleId) {
    whereQuery.where['ruleId'] = filters.ruleId;
    countQuery.where['ruleId'] = filters.ruleId;
  }

  if (include.includes('subCategories')) {

     whereQuery.include.push(
      {
        model: SubCategory,
        as: "subCategories"
      }
     )
  }

  if (include.includes('categories')) {
    
    whereQuery.include.push(
     {
       model: Category,
       as: "categories"
     }
    )
 }

 if (include.includes('department')) {
    
  whereQuery.include.push(
   {
     model: Department,
     as: "department"
   }
  )
}

  const count = await Rule.count(countQuery);
  const result = await Rule.findAll(whereQuery);
  return { result, count };
};

exports.deleteRules = async (req, res) => {
 const { ruleId } = req.params;
 try {
  const findRule = await Rule.findByPk(ruleId);
  if (!findRule) {
    return res.status(404).json({
      code: ERROR_CODES.NOT_FOUND,
      error: "Rules not found"
    })
  }

  await Rule.destroy({ where: { ruleId: ruleId }});
  return res.status(200).json({
    code: ERROR_CODES.SUCCESS,
  })
 } catch (error) {
  return handleCatchError(error, req)
 }
}

exports.updateRules = async (req, res) => {
  try {
    const { ruleId } = req.params;
    const data = req.body;
    if (!data.orderBy || !isInteger(+data.orderBy) || +data.orderBy === 0) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide orderBy",
        key: "orderBy"
      });
    }

    if (!data.categoryId || !isInteger(+data.categoryId) || +data.categoryId === 0) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide Category",
        key: "categoryId"
      });
    }

    if (!data.subCategoryId || !isInteger(+data.subCategoryId) || +data.subCategoryId === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide subCategoryId",
          key: "subCategoryId"
        });
      }

      if (!data.ratiosRawpack || !isInteger(+data.ratiosRawpack) || +data.ratiosRawpack === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide RatiosRawpack",
          key: "ratiosRawpack"
        });
      }  

      if (!data.ratiosCopack || !isInteger(+data.ratiosCopack) || +data.ratiosCopack === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide RatiosCopack",
          key: "ratiosCopack"
        });
      }
      const VALID_SCORES = ['0', '1', '2', '2.5', '3', '4', '5', '6', '7', '7.5', '8', '9', '10', 'NA'];

if (!data.score || !VALID_SCORES.includes(data.score)) {
    return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide a valid score. Valid values are: '0', '1', '2', '2.5', '3', '4', '5', '6', '7', '7.5', '8', '9', '10', 'NA'.",
        key: "score"
    });
}

if (!data.departmentId || !isInteger(+data.departmentId) || +data.departmentId === 0) {
  return res.status(400).json({
    code: ERROR_CODES.INVALID_PARAMS,
    error: "Please provide departmentId",
    key: "departmentId"
  });
}

const [findsupplierCategory, findprocurementCategory, findDepartment, findRule] = await Promise.all([
  Category.findOne({ where: { categoryId: data.categoryId }}),
  SubCategory.findOne({ where: { subCategoryId: data.subCategoryId }}), 
  Department.findOne({ where: { departmentId: data.departmentId }}), 
  Rule.findOne({ where: { ruleId: ruleId }}), 

 ])
 
 if (!findsupplierCategory) {
   return res.status(404).json({
     code: ERROR_CODES.NOT_FOUND,
     error: "Category not found"
   })
 }

 if (!findprocurementCategory) {
   return res.status(404).json({
     code: ERROR_CODES.NOT_FOUND,
     error: "Sub Category not found"
   })
 }

 if (!findDepartment) {
   return res.status(404).json({
     code: ERROR_CODES.NOT_FOUND,
     error: " Department not found"
   })
 }

 if (!findRule) {
  return res.status(404).json({
    code: ERROR_CODES.NOT_FOUND,
    error: " Rule not found"
  })
}

const doc = {
  "departmentId": data.departmentId,
  "orderBy": data.orderBy,
  "section": data.section || null,
  "categoryId": data.categoryId,
  "subCategoryId": data.suppCategoryId,
  "ratedCriteria": data.ratedCriteria || null,
  "criteriaEvaluation": data.criteriaEvaluation || null,
  "score": data.score || '0',
  "ratiosRawpack": data.ratiosRawpack || 0,
  "ratiosCopack": data.ratiosCopack || 0,
}

const updateRule = await Rule.update(doc,{ where: { ruleId: ruleId }});
return res.status(200).json({
  code: ERROR_CODES.SUCCESS,
  data: updateRule
})

  } catch (error) {
    return handleCatchError(error, req, res)
  }
}




