const express = require('express');
const { addRule, addBulkRules, getRulesByCatSubCat, getAllRules, deleteRules, updateRules } = require('../controllers/rule.controller');
const upload = require('../../../middlewares/upload');
const validateFiles = require('../../../middlewares/validateFiles');
const { authenticateToken } = require('../../../middlewares/auth');
const router = express.Router();

router.post("/rules", addRule);
router.post("/bulk-rules", upload.single("file"), validateFiles , addBulkRules);
router.get("/rules/:catId/:subCatId/:departmentId",  getRulesByCatSubCat);
router.get("/rules", authenticateToken, getAllRules);
router.delete("/rules/:ruleId", authenticateToken, deleteRules);
router.put("/rules/:ruleId", authenticateToken, updateRules);


module.exports = router
  