const XLSX = require('xlsx'); // Import xlsx library    
const { handleCatchError } = require('../../../utils/error.service');
const { ERROR_CODES } = require('../../../config/constant');
const { isInteger } = require('lodash');
const { getModel } = require('../../../modelManager');
const { where, Op } = require('sequelize');
const { parseQueryStringToObject } = require('../../../utils/util');
const Category = getModel('Category');
const SubCategory = getModel('SubCategory');
const Factory = getModel('Factory');
const Supplier = getModel('Supplier');
const Locations = getModel('Locations');
const Sublocations = getModel('Sublocations');

exports.addSupplier = async (req,res)=>{

try {
    const data = req.body;
    const gmpFile = req.files?.gmpFile?.[0] || null;
    const gdpFile = req.files?.gdpFile?.[0] || null;
    const reachFile = req.files?.reachFile?.[0] || null;
    const isoFile = req.files?.isoFile?.[0] || null;
  
    if (!data.supplierName) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide supplier name",
        key: "supplierName"
      });
    }

    if (!data.supplierManufacturerName) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide supplier manufacturer name",
        key: "supplierManufacturerName"
      });
    }

    if (!data.siteAddress) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide site address",
        key: "siteAddress"
      });
    }
    if (!data.factoryId || !isInteger(+data.factoryId) || +data.factoryId === 0) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide a valid factoryId",
        key: "factoryId"
      });
    }
    
    if (!data.procurementCategoryId || !isInteger(+data.procurementCategoryId) || +data.procurementCategoryId === 0) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide a valid procurementCategory",
        key: "procurementCategory"
      });
    }
    
    if (!data.supplierCategoryId || !isInteger(+data.supplierCategoryId) || +data.supplierCategoryId === 0) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide a valid supplierCategory",
        key: "supplierCategory"
      });
    }
    
    if (!data.locationId) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide locationId",
        key: "locationId"
      });
    }

    if (!data.sublocationId) {
      return res.status(400).json({
        code: ERROR_CODES.INVALID_PARAMS,
        error: "Please provide sublocationId",
        key: "sublocationId"
      });
    } 
    const [findsupplierCategory, findprocurementCategory, findFactory, findLocations, findSublocations] = await Promise.all([
     Category.findOne({ where: { categoryId: data.supplierCategoryId }}),
     SubCategory.findOne({ where: { subCategoryId: data.procurementCategoryId }}),
     Factory.findOne({ where: { factoryId: data.factoryId }}),
     Locations.findOne({ where: { locationId: data.locationId }}),
     Sublocations.findOne({ where: { sublocationId: data.sublocationId }}),

    ])
    
    if (!findsupplierCategory) {
      return res.status(404).json({
        code: ERROR_CODES.NOT_FOUND,
        error: "Suplier Category not found"
      })
    }

    if (!findprocurementCategory) {
      return res.status(404).json({
        code: ERROR_CODES.NOT_FOUND,
        error: "Procurement Category not found"
      })
    }

    if (!findFactory) {
      return res.status(404).json({
        code: ERROR_CODES.NOT_FOUND,
        error: "Factory not found"
      })
    }

    if (!findLocations) {
      return res.status(404).json({
        code: ERROR_CODES.NOT_FOUND,
        error: "Location not found"
      })
    }

    if (!findSublocations) {
      return res.status(404).json({
        code: ERROR_CODES.NOT_FOUND,
        error: "Sublocation not found"
      })
    }

   const doc = {
    "supplierName": data.supplierName,
    "supplierNumber": data.supplierNumber,
    "supplierManufacturerName": data.supplierManufacturerName,
    "siteAddress": data.siteAddress,
    "factoryId" : data.factoryId,
    "procurementCategoryId": data.procurementCategoryId,
    "supplierCategoryId": data.supplierCategoryId,
    "locationId": data.locationId,
    "sublocationId": data.sublocationId,
    "factory": data.factory || null
   }
  console.log(doc);
  const createSupplier =  await Supplier.create(doc);
  return res.status(200).json({
    code: ERROR_CODES.SUCCESS,
    data: createSupplier
  })
   
} catch (error) {
    return handleCatchError(error, req, res)
};
    
}

exports.updateSupplier = async (req,res)=>{

  try {
      const data = req.body;
      const { supId } = req.params;
      const gmpFile = req.files?.gmpFile?.[0] || null;
      const gdpFile = req.files?.gdpFile?.[0] || null;
      const reachFile = req.files?.reachFile?.[0] || null;
      const isoFile = req.files?.isoFile?.[0] || null;
      
      if (!data.supplierName) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide supplier name",
          key: "supplierName"
        });
      }
  
      if (!data.supplierManufacturerName) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide supplier manufacturer name",
          key: "supplierManufacturerName"
        });
      }
  
      if (!data.siteAddress) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide site address",
          key: "siteAddress"
        });
      }
      if (!data.factoryId || !isInteger(+data.factoryId) || +data.factoryId === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide a valid factoryId",
          key: "factoryId"
        });
      }
      
      if (!data.procurementCategoryId || !isInteger(+data.procurementCategoryId) || +data.procurementCategoryId === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide a valid procurementCategory",
          key: "procurementCategory"
        });
      }
      
      if (!data.supplierCategoryId || !isInteger(+data.supplierCategoryId) || +data.supplierCategoryId === 0) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide a valid supplierCategory",
          key: "supplierCategory"
        });
      }

      if (!data.locationId) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide locationId",
          key: "locationId"
        });
      }
  
      if (!data.sublocationId) {
        return res.status(400).json({
          code: ERROR_CODES.INVALID_PARAMS,
          error: "Please provide sublocationId",
          key: "sublocationId"
        });
      } 
    
  
      if (data.gmpFile) {
  
      }
  
      const [findsupplierCategory, findprocurementCategory, findFactory, findSupplier, findLocations, findSublocations] = await Promise.all([
       Category.findOne({ where: { categoryId: data.supplierCategoryId }}),
       SubCategory.findOne({ where: { subCategoryId: data.procurementCategoryId }}),
       Factory.findOne({ where: { factoryId: data.factoryId }}),
       Supplier.findOne({ where: { supId }}),
       Locations.findOne({ where: { locationId: data.locationId }}),
       Sublocations.findOne({ where: { sublocationId: data.sublocationId }}),
  
      ])

      if (!findSupplier) {
        return res.status(404).json({
          code: ERROR_CODES.NOT_FOUND,
          error: "Suplier  not found"
        })
      }

      if (!findsupplierCategory) {
        return res.status(404).json({
          code: ERROR_CODES.NOT_FOUND,
          error: "Suplier Category not found"
        })
      }
  
      if (!findprocurementCategory) {
        return res.status(404).json({
          code: ERROR_CODES.NOT_FOUND,
          error: "Procurement Category not found"
        })
      }
  
      if (!findFactory) {
        return res.status(404).json({
          code: ERROR_CODES.NOT_FOUND,
          error: "Factory not found"
        })
      }

      if (!findLocations) {
        return res.status(404).json({
          code: ERROR_CODES.NOT_FOUND,
          error: "Location not found"
        })
      }
  
      if (!findSublocations) {
        return res.status(404).json({
          code: ERROR_CODES.NOT_FOUND,
          error: "Sublocation not found"
        })
      }
  
     const doc = {
      "supplierName": data.supplierName,
      "supplierNumber": data.supplierNumber,
      "supplierManufacturerName": data.supplierManufacturerName,
      "siteAddress": data.siteAddress,
      "factoryId" : data.factoryId,
      "procurementCategoryId": data.procurementCategoryId,
      "supplierCategoryId": data.supplierCategoryId,
      "warehouseLocation": data.warehouseLocation,
      "factory": data.factory || null,
      "locationId": data.locationId,
      "sublocationId": data.sublocationId,
     }
    const updateSupplier =  await Supplier.update(doc, { where: { supId }});
    return res.status(200).json({
      code: ERROR_CODES.SUCCESS,
      data: updateSupplier
    })
     
  } catch (error) {
      return handleCatchError(error, req, res)
  };
      
  }
exports.deleteSupplier = async (req,res)=>{
  try {
    const { supId } = req.params;
    const findSupplier = await  Supplier.findOne({ where: { supId }});
    if (!findSupplier) {
      return res.status(404).json({
        code: ERROR_CODES.NOT_FOUND,
        error: "Suplier  not found"
      })
    }

    const deletSupplier =  await Supplier.destroy({ where: { supId }});
    return res.status(200).json({
      code: ERROR_CODES.SUCCESS,
      data: deletSupplier
    })
     
  } catch (error) {
    return handleCatchError(error, req, res)
  }
} 

exports.getSuppliers = async (req, res) => {
  try {
      const { companyId } = req.params;
      const {
          limit = 100,
          page = 1,
          filters = {},
          sortBy = '',
          sortOrder = '',
          include = [],
      } = parseQueryStringToObject(req.query);

      const limitNumber = parseInt(limit, 10) || 100;
      const pageNumber = parseInt(page, 10) || 1;
      const offset = (pageNumber - 1) * limitNumber;

      const { result, count } = await this.getSuppliersList({
          companyId,
          offset: offset,
          limit: limitNumber,
          filters: typeof filters === 'object' ? filters : {},
          sortBy,
          sortOrder
      });

      return res.status(200).json({
          code: ERROR_CODES.SUCCESS,
          page: pageNumber,
          limit: limitNumber,
          total: count,
          data: result,
          totalPages: Math.ceil(count / limitNumber),
          filters: filters,
      });
  } catch (error) {
      return handleCatchError(error, req, res);
  }
};

exports.getSuppliersList = async (params) => {
  const {
      companyId,
      offset,
      limit,
      filters = {},
      sortBy,
      sortOrder
  } = params;

  const countQuery = {
      where: { },
      include: []
  };

  const whereQuery = {
      where: { },
      offset: offset,
      limit: limit,
      include: [
        {
          model: Category,
          as: 'category'
        },
        {
          model: SubCategory,
          as: 'subCategories'
        },
        {
          model: Factory,
          as: 'factoryName'
        },
        {
          model: Locations,
          as: 'location'
        },
        {
          model: Sublocations,
          as: 'sublocations'
        }
    ]
  };

  whereQuery.order = [
      sortBy ? [sortBy, ['asc', 'desc'].includes(sortOrder) ? sortOrder : 'desc'] : ['supId', 'desc']
  ];



  if (filters.supplierCategoryId) {
      whereQuery.where['supplierCategoryId'] = filters.supplierCategoryId;
      countQuery.where['supplierCategoryId'] = filters.supplierCategoryId;
  }
  if (filters.procurementCategoryId) {
      whereQuery.where['procurementCategoryId'] = filters.procurementCategoryId;
      countQuery.where['procurementCategoryId'] = filters.procurementCategoryId;
  }

  if (filters.factoryId) {
    whereQuery.where['factoryId'] = filters.factoryId;
    countQuery.where['factoryId'] = filters.factoryId;
  }

  if (filters.sublocationId) {
    whereQuery.where['sublocationId'] = filters.sublocationId;
    countQuery.where['sublocationId'] = filters.sublocationId;
  }
  
  if (filters.locationId) {
    whereQuery.where['locationId'] = filters.locationId;
    countQuery.where['locationId'] = filters.locationId;
  }

  const count = await Supplier.count(countQuery);
  const result = await Supplier.findAll(whereQuery);
  return { result, count };
};