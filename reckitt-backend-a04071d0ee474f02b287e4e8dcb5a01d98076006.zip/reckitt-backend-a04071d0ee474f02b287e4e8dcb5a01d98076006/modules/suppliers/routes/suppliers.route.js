const express = require('express');
const { addSupplier, updateSupplier, deleteSupplier, getSuppliers } = require('../controllers/suppliers.controller');
const upload = require('../../../middlewares/upload');
const validateFiles = require('../../../middlewares/validateFiles');
const { authenticateToken } = require('../../../middlewares/auth');
const router = express.Router();

router.post("/supplier",authenticateToken, upload.fields([
    { name: 'gmpFile', maxCount: 1 },
    { name: 'gdpFile', maxCount: 1 },
    { name: 'reachFile', maxCount: 1 },
    { name: 'isoFile', maxCount: 1 }
  ]),validateFiles, addSupplier);
  
router.get("/supplier",authenticateToken, getSuppliers);
router.put("/supplier/:supId", upload.fields([
    { name: 'gmpFile', maxCount: 1 },
    { name: 'gdpFile', maxCount: 1 },
    { name: 'reachFile', maxCount: 1 },
    { name: 'isoFile', maxCount: 1 }
]), updateSupplier);

router.delete("/supplier/:supId",authenticateToken, deleteSupplier)
module.exports = router